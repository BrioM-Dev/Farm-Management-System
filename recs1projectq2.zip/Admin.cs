﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FarmManagementSystem
{
    internal class Admin : Person, IManagement
    {
        string filePath = Path.Combine(Directory.GetCurrentDirectory(), "animals.txt");
        private List<string> animals = new List<string>(); // A list to store animals

      
        public Admin(string Name, int Age, string ID) : base(Name, Age, ID) { }

        public string SearchByID(int id)
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                string findID = line.Substring(0, line.IndexOf(" "));
                if (findID == id.ToString())
                    return line;
            }
            return "";
        }
        public void AddAnimal(int AnimalID, string AnimalName, int AnimalAge, string Species)
        {
            if (SearchByID(AnimalID) == "")
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    Animal animal = new Animal(AnimalID, AnimalName, AnimalAge, Species);
                    string addLine = AnimalID.ToString() + " " + AnimalName +" " + AnimalAge.ToString() + " " +  Species.ToString();
                    writer.WriteLine(addLine);

                    Console.WriteLine("Animal of ID {AnimalID} has been added to the repository.");

                }
            }

            else
                Console.WriteLine("Animal of ID {AnimalID} already exists.");
        }

        public void RemoveAnimal(int AnimalID)
        {
            if (SearchByID(AnimalID) != "")
            {
                int i = 0;
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    if (line.SubString(0, line.IndexOf(" ")) != AnimalID.ToString())
                    {
                        animals[i] = line;
                        i++;
                    }
                }
                if (FileExists)            
                File.WriteAllLines(filePath, animals);
            }
            else
                Console.WriteLine("Animal of ID {AnimalID} does not exist.");
        }

        public void ListAnimals()
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                string[] words = line.Split(' ');
                Console.WriteLine($"ID: {words[0]} \t Name: {words[1]} \t Age: {words[2]} \t Species: {words[3]}");
            }
        }
    }
}