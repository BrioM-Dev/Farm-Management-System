﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace FarmManagementSystem
{
    internal class Farmer: Person
    {
        string filePath = Path.Combine(Directory.GetCurrentDirectory(), "animals.txt");
        public Farmer(string Name, int Age, string ID) : base(Name, Age, ID) { }
        public string SearchByID(int id)
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                string findID = line.Substring(0, line.IndexOf(" "));
                if (findID == id.ToString())
                    return line;
            }
            return "";
        }
        public void viewAnimalDetails(int AnimalID)
        {string result = (time < 18) ? "Good day." : "Good evening.";
            Conole.Writeline(SearchByID(AnimalID) != "" ? SearchByID(AnimalID) : "Error: {AnimalID} does not exist.");
        }
        public void viewAllAnimalsDetails()
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                string[] words = line.Split(' ');
                Console.WriteLine($"ID: {words[0]} \t Name: {words[1]} \t Age: {words[2]} \t Species: {words[3]}");
            }
        }
          
    }
}
