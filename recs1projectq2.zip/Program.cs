﻿using System;
using System.Collections.Generic;
namespace FarmManagementSystem
{
    internal class Program: IAccount
    {
        bool Login(string username, string password, Dictionary a)
        {
            if (a.ContainsKey(username))
            {
                if (admin[username] == password)
                    return true;
            }

            return false;
        }
        static void Main(string[] args)
        {
            Dictionary<string, string> admin = new Dictionary<string, string> ();
            admin.Add("Petri Gryph", "1epercomm23");
            
            Dictionary<string, string> users = new Dictionary<string, string> ();
            users.Add("Kamogelo Molope", "qwerty24");
            users.Add("Hope Samson", "12345678");
            users.Add("Tshepo Bopelo", "htrt353");
            users.Add("Gary Hamilton", "apple123");
            bool running = true;
            bool adminRunning = false;
            bool farmerRunning = false;
            int type, menuChoice;
            
            while (running)
            {
                Console.WriteLine("What type of user are you? (Choose):\n  1: Admin \n  2: Farmer\n  3: Exit main menu");
                type = Console.ReadLine();
                string username, password;
                int age, id;
                switch (type)
                {
                    case 1:
                        
                        Console.Write("Enter your username: ");
                        username = Console.ReadLine();
                        Console.Write("Enter your password: ");
                        password = Console.ReadLine();

                        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                        {
                            throw new Exception("username or password must not be null or empty.");
                            break;
                        }
                        else
                        {
                            if (Login(username, password, admin))
                            {
                                Console.Write("Enter your age: ");
                                age = Console.ReadLine();
                                Console.Write("Enter your id: ");
                                id = Console.ReadLine();
                                Admin admin = new Admin(username, age, id);
                                adminRunning = true;
                                int animalId, animalAge;
                                string animalName, species;
                                while (adminRunning)
                                {
                                    Console.WriteLine("Admin Menu:\n  1: Add new animal\n  2: Remove animal\n  3: View list of animals\n  4: Exit admin menu");
                                    switch (menuChoice)
                                    {
                                        case 1:
                                            Console.Write("Enter animal ID: ");
                                            animalId = Console.ReadLine();
                                            Console.Write("Enter animal name: ");
                                            animalName = Console.ReadLine();
                                            Console.Write("Enter animal age: ");
                                            animalAge = Console.ReadLine();
                                            Console.Write("Enter animal species: ");
                                            Species = Console.ReadLine();

                                            admin.AddAnimal(animalId,animalName, animalAge, species);
                                            break;
                                        case 2:
                                            Console.Write("Enter animal ID to remove animal: ");
                                            animalId = Console.ReadLine();
                                            admin.RemoveAnimal(animalId);
                                            break; 
                                        case 3:
                                            admin.ListAnimals();
                                            break;
                                        case 4:
                                            adminRunning = false;
                                            Console.WriteLine("Exiting admin menu...");
                                            break;
                                        default:
                                            Console("Invalid menu option selected.");
                                            break;
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Invalid username or password.");
                                break;
                            }
                        }
                        break;
                    case 2:

                        Console.Write("Enter your username: ");
                        username = Console.ReadLine();
                        Console.Write("Enter your password: ");
                        password = Console.ReadLine();

                        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                        {
                            throw new Exception("username or password must not be null or empty.");
                            break;
                        }
                        else
                        {
                            if (Login(username, password, admin))
                            {
                                Console.Write("Enter your age: ");
                                age = Console.ReadLine();
                                Console.Write("Enter your id: ");
                                id = Console.ReadLine();
                                Farmer farmer = new Farmer(username, age, id);
                                farmerRunning = true;
                                int animalId;
                                while (farmerRunning)
                                {
                                    Console.WriteLine("Farmer Menu:\n  1: View detail on animal (specified) by ID\n  2: View details of all animals\n  3: Exit farmer menu");
                                    switch (menuChoice)
                                    {
                                        case 1:
                                            animalId = Console.ReadLine();
                                            farmer.viewAnimalDetails(animalId);
                                            break;
                                        case 2:
                                            farmer.viewAllAnimalsDetails();
                                            break;
                                        case 3:
                                            farmerRunning = false;
                                            Console.WriteLine("Exiting farmer menu...");
                                            break;
                                        default:
                                            Console("Invalid menu option selected.");
                                            break;
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("Wrong username or password.");
                                break;
                            }
                        }
                        break;
                    case 3:
                        running = false;
                        Console.WriteLine("Exiting main menu...");
                        break;
                    case 4:
                        Console("Invalid menu option selected.");
                        break;


                }
            }
        }
    }
}
